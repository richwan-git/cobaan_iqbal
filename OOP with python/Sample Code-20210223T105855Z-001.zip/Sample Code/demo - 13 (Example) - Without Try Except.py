#==================================================================
# Handling Exceptions - simple demo without using try and except
#==================================================================

#=== without a try ... except ===
birthYear = int(input("Please enter your birth year"))
print("Your age is: " + str(2018 - birthYear))


